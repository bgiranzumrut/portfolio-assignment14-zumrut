export { default } from "./HeroImage";
