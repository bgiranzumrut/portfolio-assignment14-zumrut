export { default } from "./Img";
export type { ImgProps } from "./Img.types";
