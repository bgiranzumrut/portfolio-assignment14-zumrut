export { default } from "./Card";
